import { Routes, Route } from 'react-router-dom'
import Home from './pages/Home.jsx'
import About from './pages/About.jsx'
import Developer from './pages/Developer.jsx'
import Creator from './pages/Creator.jsx'
import './App.css'

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/about" element={<About />} />
      <Route path="/developer" element={<Developer />} />
      <Route path="/creator" element={<Creator />} />
    </Routes>
  )
}

export default App